package com.eventoapp.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller 
public class EventoController {

	@RequestMapping("/cadastrarEvento") // URL DE REQUISIÇÃO PARA CONTROLLER 
	public String form() {
		return "eventos/FormEvento"; //HIERARQUIA DE PASTAS 
	}
	
}
